Copy config.ini.sample to config.ini, and update it to reflect your environment.
