Tests that still need to be completed
=====================================

Keystone
--------
- Validate proper response /v2.0/services

- Validate proper response /v2.0/endpoints

- Validate creation of endpoints

  - Validate proper creation

  - Validate improper creation fails

Horizon
-------

Glance
------
- verify public/private attributes restrict images to a single tenant

Nova
----

Swift
-----

