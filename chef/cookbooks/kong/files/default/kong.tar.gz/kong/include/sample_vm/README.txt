You will need to download an image into this directory.. Will also need to update the tests to reference this new image.
